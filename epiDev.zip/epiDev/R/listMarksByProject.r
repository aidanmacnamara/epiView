#' lists availablity of markers by project
#'
#' @param x
#'
#' @return
#' @export
#'
#' @examples
listMarksByProject=function(x){

  z <<- x

  print(ls())
  names(x$tmp)



}
